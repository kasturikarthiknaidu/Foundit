/**
 * FoundIt - Mock Fetch API Handler
 * Simulates RESTful async API calls with LocalStorage caching
 */

const STORAGE_KEY_ITEMS = 'foundit_items_db';
const STORAGE_KEY_CLAIMS = 'foundit_claims_db';

// Initial Sample Data (Campus scenario grounded in view.pdf)
const INITIAL_ITEMS = [
    {
        id: 'item-001',
        type: 'Lost',
        title: 'Black Sony Over-Ear Headphones',
        category: 'Electronics',
        location: 'Library',
        date: '2026-11-18',
        description: 'Black Sony noise cancelling headphones with black carrying case.',
        photoUrl: '',
        status: 'Open',
        createdAt: '2026-11-18T10:00:00Z'
    },
    {
        id: 'item-002',
        type: 'Found',
        title: 'Sony Over-Ear Headphones',
        category: 'Electronics',
        location: 'Library',
        date: '2026-11-19',
        description: 'Found on Central Library 2nd floor study table. Has custom red cable adapter attached.',
        photoUrl: '',
        status: 'Open',
        createdAt: '2026-11-19T09:30:00Z'
    },
    {
        id: 'item-003',
        type: 'Found',
        title: 'AirPods Pro Case',
        category: 'Electronics',
        location: 'Library',
        date: '2026-11-17',
        description: 'White wireless charging case found near Quiet Study Zone 3.',
        photoUrl: '',
        status: 'Open',
        createdAt: '2026-11-17T14:15:00Z'
    },
    {
        id: 'item-004',
        type: 'Lost',
        title: 'HP Laptop',
        category: 'Electronics',
        location: 'Computer Lab 2',
        date: '2026-11-16',
        description: 'Silver 15-inch laptop with NASA sticker on top lid.',
        photoUrl: '',
        status: 'Open',
        createdAt: '2026-11-16T16:00:00Z'
    },
    {
        id: 'item-005',
        type: 'Found',
        title: 'Blue Hydro Flask (32oz)',
        category: 'Water Bottles',
        location: 'Gym',
        date: '2026-11-19',
        description: 'Pacific blue insulated water bottle left near basketball court bench.',
        photoUrl: '',
        status: 'Open',
        createdAt: '2026-11-19T11:00:00Z'
    },
    {
        id: 'item-006',
        type: 'Found',
        title: 'Campus Student ID Card',
        category: 'ID Cards & Documents',
        location: 'Cafeteria',
        date: '2026-11-18',
        description: 'Student ID card belonging to Engineering department student.',
        photoUrl: '',
        status: 'Claim Pending',
        createdAt: '2026-11-18T12:30:00Z'
    },
    {
        id: 'item-007',
        type: 'Lost',
        title: 'House Key Ring with Tag',
        category: 'Keys',
        location: 'Main Gate',
        date: '2026-11-15',
        description: 'Set of 3 keys on a brass ring with a green leather keychain attached.',
        photoUrl: '',
        status: 'Resolved',
        createdAt: '2026-11-15T08:00:00Z'
    },
    {
        id: 'item-008',
        type: 'Lost',
        title: 'MacBook Pro 14"',
        category: 'Electronics',
        location: 'Library',
        date: '2026-11-17',
        description: 'Space Gray laptop left on 3rd floor desk.',
        photoUrl: '',
        status: 'Open',
        createdAt: '2026-11-17T18:00:00Z'
    },
    {
        id: 'item-009',
        type: 'Found',
        title: 'Black Canvas Backpack',
        category: 'Bags & Backpacks',
        location: 'Sports Complex',
        date: '2026-11-18',
        description: 'Contains notebooks and a blue pencil case.',
        photoUrl: '',
        status: 'Open',
        createdAt: '2026-11-18T17:20:00Z'
    },
    {
        id: 'item-010',
        type: 'Found',
        title: 'Ray-Ban Prescription Glasses',
        category: 'Clothing & Accessories',
        location: 'Main Building',
        date: '2026-11-19',
        description: 'Black rimmed glasses in a brown leather hard case.',
        photoUrl: '',
        status: 'Open',
        createdAt: '2026-11-19T08:15:00Z'
    }
];

class MockFoundItApi {
    constructor() {
        if (!localStorage.getItem(STORAGE_KEY_ITEMS)) {
            localStorage.setItem(STORAGE_KEY_ITEMS, JSON.stringify(INITIAL_ITEMS));
        }
        if (!localStorage.getItem(STORAGE_KEY_CLAIMS)) {
            localStorage.setItem(STORAGE_KEY_CLAIMS, JSON.stringify([]));
        }
    }

    // GET /api/items
    async getItems() {
        return new Promise((resolve) => {
            setTimeout(() => {
                const data = JSON.parse(localStorage.getItem(STORAGE_KEY_ITEMS) || '[]');
                resolve({ ok: true, data });
            }, 100);
        });
    }

    // POST /api/items
    async createItem(newItem) {
        return new Promise((resolve) => {
            setTimeout(() => {
                const items = JSON.parse(localStorage.getItem(STORAGE_KEY_ITEMS) || '[]');
                const itemRecord = {
                    id: 'item-' + String(Date.now()).slice(-5),
                    ...newItem,
                    status: 'Open',
                    createdAt: new Date().toISOString()
                };
                items.unshift(itemRecord);
                localStorage.setItem(STORAGE_KEY_ITEMS, JSON.stringify(items));
                resolve({ ok: true, data: itemRecord });
            }, 150);
        });
    }

    // POST /api/claims
    async submitClaim(claimData) {
        return new Promise((resolve) => {
            setTimeout(() => {
                const claims = JSON.parse(localStorage.getItem(STORAGE_KEY_CLAIMS) || '[]');
                const items = JSON.parse(localStorage.getItem(STORAGE_KEY_ITEMS) || '[]');
                
                const claimRecord = {
                    id: 'claim-' + String(Date.now()).slice(-5),
                    ...claimData,
                    submittedAt: new Date().toISOString(),
                    status: 'Pending Review'
                };
                claims.unshift(claimRecord);
                localStorage.setItem(STORAGE_KEY_CLAIMS, JSON.stringify(claims));

                const targetItem = items.find(i => i.id === claimData.itemId);
                if (targetItem) {
                    targetItem.status = 'Claim Pending';
                    localStorage.setItem(STORAGE_KEY_ITEMS, JSON.stringify(items));
                }

                resolve({ ok: true, data: claimRecord });
            }, 150);
        });
    }

    // Algorithmic Matcher Engine Execution
    async getMatches() {
        const { data: items } = await this.getItems();
        const lostItems = items.filter(i => i.type === 'Lost');
        const foundItems = items.filter(i => i.type === 'Found');

        const matches = [];

        lostItems.forEach(lost => {
            foundItems.forEach(found => {
                if (lost.category === found.category) {
                    let score = 50;
                    const factors = ['Matching Category: ' + lost.category];

                    if (lost.location === found.location) {
                        score += 25;
                        factors.push('Same Campus Zone: ' + lost.location);
                    }

                    const lostTokens = lost.title.toLowerCase().split(' ').concat(lost.description.toLowerCase().split(' '));
                    const foundTokens = found.title.toLowerCase().split(' ').concat(found.description.toLowerCase().split(' '));
                    
                    const commonTokens = lostTokens.filter(t => t.length > 3 && foundTokens.includes(t));
                    if (commonTokens.length > 0) {
                        score += Math.min(20, commonTokens.length * 7);
                        factors.push('Matching terms: ' + Array.from(new Set(commonTokens)).join(', '));
                    }

                    if (score >= 65) {
                        matches.push({
                            id: `match-${lost.id}-${found.id}`,
                            lostItem: lost,
                            foundItem: found,
                            confidenceScore: Math.min(98, score),
                            matchingFactors: factors
                        });
                    }
                }
            });
        });

        return matches.sort((a, b) => b.confidenceScore - a.confidenceScore);
    }
}

const api = new MockFoundItApi();
