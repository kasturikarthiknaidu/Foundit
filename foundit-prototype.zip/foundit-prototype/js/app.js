/**
 * FoundIt - Main UI Controller
 * Integrates search, rendering, item reporting, and claim workflows
 */

let allItems = [];

document.addEventListener('DOMContentLoaded', async () => {
    await loadCatalog();
    await renderMatches();
});

function switchTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));

    const targetTab = document.getElementById(`tab-${tabName}`);
    const targetNav = document.getElementById(`nav-${tabName}`);

    if (targetTab) targetTab.classList.add('active');
    if (targetNav) targetNav.classList.add('active');

    if (tabName === 'matches') {
        renderMatches();
    }
}

async function loadCatalog() {
    const response = await api.getItems();
    if (response.ok) {
        allItems = response.data;
        renderGrid(allItems);
    }
}

function getCategoryPlaceholder(category) {
    const icons = {
        'Electronics': '🎧',
        'ID Cards & Documents': '🪪',
        'Water Bottles': '🍶',
        'Keys': '🔑',
        'Bags & Backpacks': '🎒',
        'Clothing & Accessories': '👓'
    };
    const icon = icons[category] || '📦';
    return `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="400" height="225" viewBox="0 0 400 225"><rect width="400" height="225" fill="%23F1F5F9"/><text x="50%" y="45%" dominant-baseline="middle" text-anchor="middle" font-size="48">${icon}</text><text x="50%" y="70%" dominant-baseline="middle" text-anchor="middle" font-size="14" fill="%2364748B">${encodeURIComponent(category)}</text></svg>`;
}

function renderGrid(items) {
    const grid = document.getElementById('item-grid');
    const countEl = document.getElementById('results-count');
    
    countEl.textContent = items.length;

    if (items.length === 0) {
        grid.innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: 3rem; background: white; border-radius: 8px;">
                <p style="font-size: 1.1rem; color: var(--text-muted);">No campus items matched your filter query.</p>
            </div>
        `;
        return;
    }

    grid.innerHTML = items.map(item => {
        const imgSrc = item.photoUrl || getCategoryPlaceholder(item.category);
        return `
        <article class="card">
            <div class="card-img-wrapper">
                <img src="${imgSrc}" alt="${item.title}" class="card-img">
                <span class="card-type-badge ${item.type === 'Lost' ? 'badge-lost' : 'badge-found'}">${item.type}</span>
            </div>
            <div class="card-body">
                <div class="card-meta">
                    <span class="card-category">${item.category}</span>
                    <span class="status-pill pill-${item.status.toLowerCase().replace(' ', '-')}">${item.status}</span>
                </div>
                <h3 class="card-title">${item.title}</h3>
                <p class="card-description">${item.description}</p>
                <div class="card-footer">
                    <span class="card-location">📍 ${item.location}</span>
                    <button class="btn btn-secondary btn-sm" onclick="openClaimModal('${item.id}', '${escapeHtml(item.title)}')">
                        ${item.type === 'Found' ? 'Claim Item' : 'I Found This'}
                    </button>
                </div>
            </div>
        </article>
        `;
    }).join('');
}

function handleSearch() {
    const query = document.getElementById('search-input').value.toLowerCase().trim();
    const category = document.getElementById('filter-category').value;
    const location = document.getElementById('filter-location').value;
    const status = document.getElementById('filter-status').value;
    const type = document.getElementById('filter-type').value;

    const filtered = allItems.filter(item => {
        const matchesQuery = !query || item.title.toLowerCase().includes(query) || item.description.toLowerCase().includes(query);
        const matchesCat = category === 'All' || item.category === category;
        const matchesLoc = location === 'All' || item.location === location;
        const matchesStatus = status === 'All' || item.status === status;
        const matchesType = type === 'All' || item.type === type;

        return matchesQuery && matchesCat && matchesLoc && matchesStatus && matchesType;
    });

    renderGrid(filtered);
}

async function handleReportSubmit(event) {
    event.preventDefault();
    
    const newItem = {
        type: document.getElementById('item-type').value,
        title: document.getElementById('item-title').value,
        category: document.getElementById('item-category').value,
        location: document.getElementById('item-location').value,
        date: document.getElementById('item-date').value,
        photoUrl: document.getElementById('item-photo').value || '',
        description: document.getElementById('item-description').value
    };

    const response = await api.createItem(newItem);
    if (response.ok) {
        alert('Item reported successfully! The Matching Engine is scanning for potential owner pairs.');
        document.getElementById('report-form').reset();
        await loadCatalog();
        switchTab('catalog');
    }
}

async function renderMatches() {
    const matchesContainer = document.getElementById('matches-container');
    const matchCountEl = document.getElementById('match-count');
    
    const matches = await api.getMatches();
    matchCountEl.textContent = matches.length;

    if (matches.length === 0) {
        matchesContainer.innerHTML = `
            <div style="text-align: center; padding: 3rem; background: white; border-radius: 8px;">
                <p style="color: var(--text-muted);">No automated item matches detected currently.</p>
            </div>
        `;
        return;
    }

    matchesContainer.innerHTML = matches.map(m => `
        <div class="match-pair-card">
            <div class="match-item">
                <span class="card-type-badge badge-lost">LOST REPORT</span>
                <h4 style="margin: 0.5rem 0 0.25rem 0;">${m.lostItem.title}</h4>
                <p style="font-size: 0.85rem; color: var(--text-muted);">📍 ${m.lostItem.location} • ${m.lostItem.date}</p>
            </div>

            <div class="match-badge-center">
                <span class="confidence-pill">${m.confidenceScore}% MATCH</span>
                <p style="font-size: 0.72rem; color: var(--text-muted); margin-top: 4px;">Algorithmic score</p>
            </div>

            <div class="match-item">
                <span class="card-type-badge badge-found">FOUND ENTRY</span>
                <h4 style="margin: 0.5rem 0 0.25rem 0;">${m.foundItem.title}</h4>
                <p style="font-size: 0.85rem; color: var(--text-muted);">📍 ${m.foundItem.location} • ${m.foundItem.date}</p>
                <button class="btn btn-primary btn-sm" style="margin-top: 0.5rem; width: 100%;" onclick="openClaimModal('${m.foundItem.id}', '${escapeHtml(m.foundItem.title)}')">
                    Verify & Claim Match
                </button>
            </div>
        </div>
    `).join('');
}

function openClaimModal(itemId, title) {
    document.getElementById('claim-item-id').value = itemId;
    document.getElementById('claim-item-summary').textContent = `Submitting verification claim for: "${title}"`;
    document.getElementById('claim-modal').classList.add('active');
}

function closeClaimModal() {
    document.getElementById('claim-modal').classList.remove('active');
    document.getElementById('claim-form').reset();
}

async function handleClaimSubmit(event) {
    event.preventDefault();

    const claimData = {
        itemId: document.getElementById('claim-item-id').value,
        claimantName: document.getElementById('claimant-name').value,
        claimantEmail: document.getElementById('claimant-email').value,
        privateProof: document.getElementById('claim-proof').value
    };

    const response = await api.submitClaim(claimData);
    if (response.ok) {
        alert('Verification claim submitted successfully! Campus Security office will review your private proof before releasing the item.');
        closeClaimModal();
        await loadCatalog();
    }
}

function escapeHtml(str) {
    return str.replace(/'/g, "\\'");
}
