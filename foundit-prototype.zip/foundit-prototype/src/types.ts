/**
 * FoundIt - TypeScript Data Schemas & API Contracts
 * Modules 3-4 Dynamic Phase: Typed Interfaces
 */

export type ItemType = 'Lost' | 'Found';

export type ItemStatus = 'Open' | 'Claim Pending' | 'Resolved';

export type CampusLocation = 
  | 'Library' 
  | 'Main Building' 
  | 'Cafeteria' 
  | 'Sports Complex' 
  | 'Computer Lab 2' 
  | 'Gym' 
  | 'Main Gate';

export type ItemCategory = 
  | 'Electronics' 
  | 'ID Cards & Documents' 
  | 'Water Bottles' 
  | 'Keys' 
  | 'Bags & Backpacks' 
  | 'Clothing & Accessories';

export interface LostFoundItem {
  id: string;
  type: ItemType;
  title: string;
  category: ItemCategory;
  location: CampusLocation;
  date: string;
  description: string;
  photoUrl: string;
  status: ItemStatus;
  createdAt: string;
  privateVerificationNote?: string;
}

export interface ClaimRequest {
  id: string;
  itemId: string;
  claimantName: string;
  claimantEmail: string;
  privateProof: string;
  submittedAt: string;
  status: 'Pending Review' | 'Approved' | 'Rejected';
}

export interface MatchResult {
  id: string;
  lostItem: LostFoundItem;
  foundItem: LostFoundItem;
  confidenceScore: number;
  matchingFactors: string[];
}
