/**
 * FoundIt v2 - Enterprise & Hackathon Grade TypeScript Schemas
 * Comprehensive type definitions, interfaces, and API contracts
 */

export type ItemType = 'Lost' | 'Found';

export type ItemStatus = 'Open' | 'Claim Pending' | 'Resolved';

export type CampusLocation = 
  | 'Library' 
  | 'Main Building' 
  | 'Cafeteria' 
  | 'Sports Complex' 
  | 'Computer Lab 2' 
  | 'Gym' 
  | 'Main Gate';

export type ItemCategory = 
  | 'Electronics' 
  | 'ID Cards & Documents' 
  | 'Water Bottles' 
  | 'Keys' 
  | 'Bags & Backpacks' 
  | 'Clothing & Accessories';

export interface LostFoundItem {
  id: string;
  type: ItemType;
  title: string;
  category: ItemCategory;
  location: CampusLocation;
  date: string;
  description: string;
  photoUrl: string;
  status: ItemStatus;
  createdAt: string;
  synonyms?: string[];
  contactEmail?: string;
  contactPhone?: string;
  isDuplicate?: boolean;
  duplicateOfId?: string;
  qrCodeTagId?: string;
}

export interface ClaimRequest {
  id: string;
  itemId: string;
  claimantName: string;
  claimantEmail: string;
  hashedProof: string; // Cryptographic SHA-256 hash of verification answer
  proofHint?: string;   // e.g. "Color of the case/sticker description"
  submittedAt: string;
  status: 'Pending Review' | 'Approved' | 'Rejected';
  verificationAttempts: number;
}

export interface MatchResult {
  id: string;
  lostItem: LostFoundItem;
  foundItem: LostFoundItem;
  confidenceScore: number; // 0-100 percentage
  textSimilarityScore: number;
  locationScore: number;
  dateScore: number;
  matchingFactors: string[];
  isPotentialDuplicate: boolean;
}

export interface SecurityHandoverReceipt {
  receiptId: string;
  itemId: string;
  itemTitle: string;
  category: ItemCategory;
  finderName: string;
  securityOfficerName: string;
  badgeNumber: string;
  deskLocation: CampusLocation;
  timestamp: string;
  custodyStatus: 'In Vault' | 'Claimed' | 'Transferred';
  signatureHash: string;
}

export interface PropertyTag {
  tagId: string;
  ownerName: string;
  ownerEmail: string;
  itemTitle: string;
  category: ItemCategory;
  qrDataUrl: string;
  createdAt: string;
}

export interface EngineTestResult {
  name: string;
  passed: boolean;
  message: string;
  durationMs: number;
}
