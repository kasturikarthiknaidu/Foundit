/**
 * FoundIt v2 Application Controller & UI View Manager
 * Handles DOM events, tab switching, search filtering, modals, and automated test execution
 */

import { FoundItAPI } from './api.js';
import { MatchingEngine } from './services/matchingEngine.js';
import { SecurityService } from './services/security.js';
import { QRGeneratorService } from './services/qrGenerator.js';
import { ReceiptGeneratorService } from './services/receiptGenerator.js';
import { EngineTestSuite } from './tests/engine.test.js';

let allItems = [];
let activeTab = 'catalog';

document.addEventListener('DOMContentLoaded', async () => {
  await loadItems();
  setupNavigation();
  setupSearchAndFilters();
  setupForms();
  setupModalListeners();
  runAutomatedTestsOnLoad();
});

async function loadItems() {
  allItems = await FoundItAPI.getItems();
  renderCatalog(allItems);
  renderSmartMatches();
}

function setupNavigation() {
  const navBtns = document.querySelectorAll('.nav-tab');
  navBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      navBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeTab = btn.dataset.tab;

      document.querySelectorAll('.tab-view').forEach(view => {
        view.classList.remove('active');
      });

      const activeView = document.getElementById(`view-${activeTab}`);
      if (activeView) activeView.classList.add('active');
    });
  });
}

function setupSearchAndFilters() {
  const searchInput = document.getElementById('search-input');
  const typeFilter = document.getElementById('filter-type');
  const catFilter = document.getElementById('filter-category');
  const locFilter = document.getElementById('filter-location');
  const statusFilter = document.getElementById('filter-status');

  const applyFilters = () => {
    const q = searchInput ? searchInput.value.toLowerCase().trim() : '';
    const type = typeFilter ? typeFilter.value : 'all';
    const cat = catFilter ? catFilter.value : 'all';
    const loc = locFilter ? locFilter.value : 'all';
    const status = statusFilter ? statusFilter.value : 'all';

    const filtered = allItems.filter(item => {
      const matchQ = !q || item.title.toLowerCase().includes(q) || item.description.toLowerCase().includes(q);
      const matchType = type === 'all' || item.type === type;
      const matchCat = cat === 'all' || item.category === cat;
      const matchLoc = loc === 'all' || item.location === loc;
      const matchStatus = status === 'all' || item.status === status;
      return matchQ && matchType && matchCat && matchLoc && matchStatus;
    });

    renderCatalog(filtered);
  };

  if (searchInput) searchInput.addEventListener('input', applyFilters);
  if (typeFilter) typeFilter.addEventListener('change', applyFilters);
  if (catFilter) catFilter.addEventListener('change', applyFilters);
  if (locFilter) locFilter.addEventListener('change', applyFilters);
  if (statusFilter) statusFilter.addEventListener('change', applyFilters);
}

function renderCatalog(items) {
  const grid = document.getElementById('items-grid');
  const countEl = document.getElementById('item-count');
  if (countEl) countEl.textContent = `${items.length} items cataloged`;
  if (!grid) return;

  if (items.length === 0) {
    grid.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 48px; background: #ffffff; border-radius: 12px; border: 1px dashed #cbd5e1;">
        <h3 style="color:#64748b; margin-bottom:8px;">No matching lost or found items</h3>
        <p style="color:#94a3b8;">Try adjusting your filters or search keywords.</p>
      </div>
    `;
    return;
  }

  grid.innerHTML = items.map(item => {
    const statusClass = item.status === 'Open' ? 'badge-open' : item.status === 'Claim Pending' ? 'badge-pending' : 'badge-resolved';
    const typeClass = item.type === 'Lost' ? 'type-lost' : 'type-found';
    
    return `
      <div class="item-card">
        <div class="card-image-wrap">
          <img src="${item.photoUrl}" alt="${SecurityService.sanitizeInput(item.title)}" loading="lazy"/>
          <span class="type-pill ${typeClass}">${item.type}</span>
          <span class="status-pill ${statusClass}">${item.status}</span>
        </div>
        <div class="card-body">
          <div class="card-meta">
            <span class="cat-tag">${item.category}</span>
            <span class="date-tag">🗓️ ${item.date}</span>
          </div>
          <h3 class="card-title">${SecurityService.sanitizeInput(item.title)}</h3>
          <p class="card-desc">${SecurityService.sanitizeInput(item.description)}</p>
          <div class="card-location">📍 <strong>${item.location}</strong></div>
          <div class="card-actions">
            ${item.type === 'Found' && item.status === 'Open' ? 
              `<button class="btn btn-primary claim-btn" data-id="${item.id}">🙋 Claim Item</button>` : ''}
            <button class="btn btn-secondary match-btn" data-id="${item.id}">🔍 View Matches</button>
            ${item.type === 'Found' ? `<button class="btn btn-outline receipt-btn" data-id="${item.id}">📜 Handover Receipt</button>` : ''}
          </div>
        </div>
      </div>
    `;
  }).join('');

  // Attach card event handlers
  grid.querySelectorAll('.claim-btn').forEach(btn => {
    btn.addEventListener('click', () => openClaimModal(btn.dataset.id));
  });

  grid.querySelectorAll('.match-btn').forEach(btn => {
    btn.addEventListener('click', () => showMatchesModal(btn.dataset.id));
  });

  grid.querySelectorAll('.receipt-btn').forEach(btn => {
    btn.addEventListener('click', () => generateReceiptForCard(btn.dataset.id));
  });
}

function setupForms() {
  const reportForm = document.getElementById('report-item-form');
  if (reportForm) {
    reportForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = {
        type: document.getElementById('report-type').value,
        title: document.getElementById('report-title').value,
        category: document.getElementById('report-category').value,
        location: document.getElementById('report-location').value,
        date: document.getElementById('report-date').value,
        description: document.getElementById('report-description').value,
        proofHint: document.getElementById('report-proof-hint').value
      };

      const result = await FoundItAPI.saveItem(formData);
      alert(`Report logged successfully! Item ID: ${result.item.id}`);
      reportForm.reset();
      await loadItems();
      
      // Switch back to catalog view
      document.querySelector('[data-tab="catalog"]').click();
    });
  }

  const qrForm = document.getElementById('qr-builder-form');
  if (qrForm) {
    qrForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('qr-owner-name').value;
      const title = document.getElementById('qr-item-title').value;
      const tagId = `TAG-${Math.floor(100000 + Math.random() * 900000)}`;

      const svgHTML = QRGeneratorService.generatePropertyTagSVG(tagId, name, title);
      const preview = document.getElementById('qr-preview-box');
      if (preview) {
        preview.innerHTML = svgHTML;
      }
    });
  }
}

function setupModalListeners() {
  const modal = document.getElementById('modal-overlay');
  const closeBtn = document.getElementById('modal-close');
  if (closeBtn) closeBtn.addEventListener('click', () => closeModal());
  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeModal();
    });
  }
}

function openClaimModal(itemId) {
  const item = allItems.find(i => i.id === itemId);
  if (!item) return;

  const modalBody = document.getElementById('modal-body');
  const modalTitle = document.getElementById('modal-title');
  if (modalTitle) modalTitle.textContent = `Claim Ownership: ${item.title}`;

  if (modalBody) {
    modalBody.innerHTML = `
      <p style="color:#64748b; font-size:14px; margin-bottom:16px;">
        To prevent fraudulent claims on campus valuables, your verification response will be 
        <strong>cryptographically hashed (SHA-256)</strong> before submission.
      </p>

      <form id="claim-submit-form">
        <input type="hidden" id="claim-item-id" value="${item.id}">
        <div class="form-group" style="margin-bottom:12px;">
          <label style="display:block; font-weight:600; margin-bottom:4px;">Your Full Name</label>
          <input type="text" id="claim-name" required class="form-control" style="width:100%; padding:8px; border:1px solid #cbd5e1; border-radius:6px;" placeholder="e.g. Jordan Smith">
        </div>

        <div class="form-group" style="margin-bottom:12px;">
          <label style="display:block; font-weight:600; margin-bottom:4px;">Campus Email</label>
          <input type="email" id="claim-email" required class="form-control" style="width:100%; padding:8px; border:1px solid #cbd5e1; border-radius:6px;" placeholder="jordan@campus.edu">
        </div>

        <div class="form-group" style="margin-bottom:16px;">
          <label style="display:block; font-weight:600; margin-bottom:4px;">
            Private Verification Proof 🔒
            ${item.proofHint ? `<span style="display:block; font-weight:normal; font-size:12px; color:#0284c7;">Hint from Finder: ${item.proofHint}</span>` : ''}
          </label>
          <textarea id="claim-proof" required rows="3" classform-control" style="width:100%; padding:8px; border:1px solid #cbd5e1; border-radius:6px;" placeholder="Describe unique undisclosed details (e.g., serial number, cable color, case sticker, wallpaper image)"></textarea>
        </div>

        <button type="submit" class="btn btn-primary" style="width:100%; padding:10px; font-weight:600;">🔒 Submit Cryptographically Signed Claim</button>
      </form>
    `;

    document.getElementById('claim-submit-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const claimData = {
        itemId: document.getElementById('claim-item-id').value,
        claimantName: document.getElementById('claim-name').value,
        claimantEmail: document.getElementById('claim-email').value,
        privateProof: document.getElementById('claim-proof').value
      };

      await FoundItAPI.submitClaim(claimData);
      alert('Claim submitted securely! Status updated to Claim Pending.');
      closeModal();
      await loadItems();
    });
  }

  openModal();
}

async function showMatchesModal(itemId) {
  const item = allItems.find(i => i.id === itemId);
  if (!item) return;

  const matches = await FoundItAPI.getMatches(itemId);
  const modalBody = document.getElementById('modal-body');
  const modalTitle = document.getElementById('modal-title');
  if (modalTitle) modalTitle.textContent = `Smart Match Engine: ${item.title}`;

  if (modalBody) {
    if (matches.length === 0) {
      modalBody.innerHTML = `<p style="text-align:center; padding:24px; color:#64748b;">No high-confidence matches found yet for this item.</p>`;
    } else {
      modalBody.innerHTML = `
        <div style="display:flex; flex-direction:column; gap:16px;">
          ${matches.map(m => `
            <div style="border:1px solid #e2e8f0; border-radius:8px; padding:12px; background:#f8fafc;">
              <div style="display:flex; justify-between; align-items:center; margin-bottom:8px;">
                <span style="font-weight:700; color:#0284c7;">${m.confidenceScore}% Match Confidence</span>
                <span class="type-pill ${m.foundItem.type === 'Found' ? 'type-found' : 'type-lost'}">${m.foundItem.type}</span>
              </div>
              <h4 style="margin:0 0 4px 0;">${SecurityService.sanitizeInput(m.foundItem.title)}</h4>
              <p style="font-size:12px; color:#64748b; margin:0 0 8px 0;">📍 ${m.foundItem.location} | 🗓️ ${m.foundItem.date}</p>
              <div style="display:flex; gap:6px; flex-wrap:wrap;">
                ${m.matchingFactors.map(f => `<span style="font-size:11px; background:#e0f2fe; color:#0369a1; padding:2px 6px; border-radius:4px;">✓ ${f}</span>`).join('')}
              </div>
            </div>
          `).join('')}
        </div>
      `;
    }
  }

  openModal();
}

function generateReceiptForCard(itemId) {
  const item = allItems.find(i => i.id === itemId);
  if (!item) return;

  const receipt = ReceiptGeneratorService.createReceipt(item);
  const modalBody = document.getElementById('modal-body');
  const modalTitle = document.getElementById('modal-title');
  if (modalTitle) modalTitle.textContent = `Campus Security Custody Receipt`;
  if (modalBody) {
    modalBody.innerHTML = ReceiptGeneratorService.renderReceiptHTML(receipt);
  }
  openModal();
}

function renderSmartMatches() {
  const container = document.getElementById('matches-container');
  if (!container) return;

  const lostItems = allItems.filter(i => i.type === 'Lost' && i.status === 'Open');
  const allMatchPairs = [];

  lostItems.forEach(lost => {
    const matches = MatchingEngine.findMatchesForItem(lost, allItems);
    matches.forEach(m => allMatchPairs.push(m));
  });

  allMatchPairs.sort((a, b) => b.confidenceScore - a.confidenceScore);

  if (allMatchPairs.length === 0) {
    container.innerHTML = `<p style="text-align:center; padding:24px; color:#64748b;">No active match pairs detected.</p>`;
    return;
  }

  container.innerHTML = allMatchPairs.slice(0, 10).map(m => `
    <div style="background:#ffffff; border:1px solid #cbd5e1; border-radius:12px; padding:16px; display:grid; grid-template-columns:1fr auto 1fr; gap:16px; align-items:center;">
      <div>
        <span style="font-size:11px; font-weight:700; color:#dc2626; text-transform:uppercase;">Lost Report</span>
        <h4 style="margin:4px 0;">${SecurityService.sanitizeInput(m.lostItem.title)}</h4>
        <span style="font-size:12px; color:#64748b;">📍 ${m.lostItem.location} | 🗓️ ${m.lostItem.date}</span>
      </div>

      <div style="text-align:center; padding:8px 16px; background:#f0f9ff; border-radius:8px; border:1px solid #bae6fd;">
        <span style="display:block; font-size:20px; font-weight:800; color:#0284c7;">${m.confidenceScore}%</span>
        <span style="font-size:10px; color:#0369a1; font-weight:600;">Match Confidence</span>
      </div>

      <div>
        <span style="font-size:11px; font-weight:700; color:#16a34a; text-transform:uppercase;">Found Discovery</span>
        <h4 style="margin:4px 0;">${SecurityService.sanitizeInput(m.foundItem.title)}</h4>
        <span style="font-size:12px; color:#64748b;">📍 ${m.foundItem.location} | 🗓️ ${m.foundItem.date}</span>
      </div>
    </div>
  `).join('');
}

async function runAutomatedTestsOnLoad() {
  const container = document.getElementById('test-results-container');
  if (!container) return;

  const results = await EngineTestSuite.runAllTests();
  const allPassed = results.every(r => r.passed);

  container.innerHTML = `
    <div style="background:${allPassed ? '#f0fdf4' : '#fef2f2'}; border:1px solid ${allPassed ? '#bbf7d0' : '#fecaca'}; border-radius:8px; padding:16px; margin-bottom:16px;">
      <h3 style="margin:0 0 8px 0; color:${allPassed ? '#166534' : '#991b1b'}; display:flex; align-items:center; gap:8px;">
        ${allPassed ? '✅ All Matching & Security Tests Passed (100% Score)' : '❌ Some Tests Failed'}
      </h3>
      <p style="margin:0; font-size:13px; color:#475569;">Verification suite executing live in browser against TypeScript contracts and JS Services.</p>
    </div>

    <div style="display:flex; flex-direction:column; gap:8px;">
      ${results.map(r => `
        <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:6px; padding:10px 14px; display:flex; justify-between; align-items:center; font-size:13px;">
          <div>
            <strong>${r.name}</strong>
            <span style="display:block; font-size:11px; color:#64748b;">${r.message}</span>
          </div>
          <span style="font-weight:700; color:${r.passed ? '#16a34a' : '#dc2626'}; font-family:monospace;">${r.passed ? 'PASS' : 'FAIL'} (${r.durationMs}ms)</span>
        </div>
      `).join('')}
    </div>
  `;
}

function openModal() {
  const modal = document.getElementById('modal-overlay');
  if (modal) modal.classList.add('active');
}

function closeModal() {
  const modal = document.getElementById('modal-overlay');
  if (modal) modal.classList.remove('active');
}
