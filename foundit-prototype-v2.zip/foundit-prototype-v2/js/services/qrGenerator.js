/**
 * FoundIt v2 QR Code Smart Property Tag Generator
 * Generates vector SVG QR codes for student property tagging
 */

export class QRGeneratorService {
  /**
   * Generates a clean SVG QR code placeholder representation for property tags
   */
  static generatePropertyTagSVG(tagId, ownerName, itemTitle) {
    const safeTitle = itemTitle || 'Campus Property';
    const safeOwner = ownerName || 'Campus Student';
    const safeId = tagId || 'TAG-0000';

    return `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 400" width="100%" height="100%" style="border-radius: 12px; background: #ffffff; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
        <rect width="320" height="400" fill="#ffffff" rx="12"/>
        <rect width="320" height="75" fill="#1e293b" rx="12 12 0 0"/>
        
        <text x="160" y="32" font-family="system-ui, sans-serif" font-size="18" font-weight="700" fill="#38bdf8" text-anchor="middle">FOUNDIT SMART TAG</text>
        <text x="160" y="54" font-family="system-ui, sans-serif" font-size="11" fill="#94a3b8" text-anchor="middle">Campus Property Recovery Protocol</text>
        
        <g transform="translate(60, 95)">
          <rect width="200" height="200" fill="#f8fafc" stroke="#cbd5e1" stroke-width="2" rx="8"/>
          
          <rect x="15" y="15" width="45" height="45" fill="#0f172a"/>
          <rect x="22" y="22" width="31" height="31" fill="#ffffff"/>
          <rect x="29" y="29" width="17" height="17" fill="#0f172a"/>
          
          <rect x="140" y="15" width="45" height="45" fill="#0f172a"/>
          <rect x="147" y="22" width="31" height="31" fill="#ffffff"/>
          <rect x="154" y="29" width="17" height="17" fill="#0f172a"/>
          
          <rect x="15" y="140" width="45" height="45" fill="#0f172a"/>
          <rect x="22" y="147" width="31" height="31" fill="#ffffff"/>
          <rect x="29" y="154" width="17" height="17" fill="#0f172a"/>

          <rect x="75" y="25" width="12" height="12" fill="#0284c7"/>
          <rect x="95" y="25" width="12" height="12" fill="#0f172a"/>
          <rect x="115" y="25" width="12" height="12" fill="#0284c7"/>
          <rect x="75" y="45" width="12" height="12" fill="#0f172a"/>
          <rect x="115" y="45" width="12" height="12" fill="#0f172a"/>

          <circle cx="100" cy="100" r="18" fill="#ffffff" stroke="#0284c7" stroke-width="2"/>
          <text x="100" y="105" font-family="system-ui" font-size="12" font-weight="bold" fill="#0284c7" text-anchor="middle">FI</text>
        </g>

        <text x="160" y="318" font-family="system-ui, sans-serif" font-size="14" font-weight="600" fill="#0f172a" text-anchor="middle">${safeTitle}</text>
        <text x="160" y="338" font-family="system-ui, sans-serif" font-size="12" fill="#64748b" text-anchor="middle">Owner: ${safeOwner}</text>
        <text x="160" y="358" font-family="monospace" font-size="11" fill="#0284c7" text-anchor="middle">TAG ID: ${safeId}</text>
        <text x="160" y="380" font-family="system-ui, sans-serif" font-size="10" fill="#94a3b8" text-anchor="middle">Scan to report found item to owner</text>
      </svg>
    `;
  }
}
