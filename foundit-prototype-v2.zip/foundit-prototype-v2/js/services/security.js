/**
 * FoundIt v2 Security Module
 * Client-side SHA-256 Hashing, Input Sanitization (XSS Prevention), and Verification Protection
 */

export class SecurityService {
  /**
   * Generates a SHA-256 hex hash for sensitive text (e.g., verification answers)
   * Prevents storing raw private proofs in LocalStorage.
   */
  static async hashText(text) {
    if (!text) return '';
    const normalized = text.trim().toLowerCase();
    
    if (typeof window !== 'undefined' && window.crypto && window.crypto.subtle) {
      try {
        const encoder = new TextEncoder();
        const data = encoder.encode(normalized);
        const hashBuffer = await window.crypto.subtle.digest('SHA-256', data);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
      } catch (e) {
        console.warn('Crypto API failed, falling back to simple hash', e);
      }
    }
    
    // Pure JS Fallback Hash (fnv1a variant 32-bit hex)
    let hash = 0x811c9dc5;
    for (let i = 0; i < normalized.length; i++) {
      hash ^= normalized.charCodeAt(i);
      hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
    }
    return (hash >>> 0).toString(16).padStart(8, '0');
  }

  /**
   * Sanitizes user input strings to prevent Cross-Site Scripting (XSS)
   */
  static sanitizeInput(str) {
    if (typeof str !== 'string') return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  /**
   * Validates claim proof input against stored hash
   */
  static async verifyProof(inputProof, storedHash) {
    const inputHash = await this.hashText(inputProof);
    return inputHash === storedHash;
  }

  /**
   * Validates email format
   */
  static isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
  }
}
