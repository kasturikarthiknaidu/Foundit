/**
 * FoundIt v2 Intelligent Item Matching Engine
 * Advanced Cosine Similarity, Synonym Normalization, Multi-attribute Weighting, and Duplicate Detection
 */

export class MatchingEngine {
  // Synonym Dictionary for Campus Terminology Normalization
  static SYNONYM_MAP = {
    'macbook': ['apple', 'laptop', 'computer', 'notebook', 'air', 'pro'],
    'laptop': ['macbook', 'notebook', 'computer', 'thinkpad', 'dell', 'hp', 'chromebook', 'asus', 'lenovo'],
    'airpods': ['earbuds', 'headphones', 'earphones', 'headset', 'bose', 'sony', 'airpod'],
    'headphones': ['airpods', 'earbuds', 'earphones', 'headset', 'sony', 'bose', 'beats'],
    'hydroflask': ['bottle', 'flask', 'waterbottle', 'thermos', 'tumbler', 'cup', 'yeti'],
    'bottle': ['hydroflask', 'flask', 'waterbottle', 'thermos', 'tumbler', 'cup'],
    'id': ['card', 'badge', 'pass', 'student id', 'license', 'campus card'],
    'card': ['id', 'badge', 'pass', 'license', 'campus card', 'credit card'],
    'keys': ['keychain', 'fob', 'car key', 'house key', 'ring'],
    'bag': ['backpack', 'tote', 'duffel', 'purse', 'pouch', 'case', 'sack'],
    'backpack': ['bag', 'tote', 'duffel', 'rucksack'],
    'glasses': ['spectacles', 'sunglasses', 'bifocals', 'frames', 'rayban']
  };

  static STOP_WORDS = new Set([
    'a', 'an', 'the', 'in', 'on', 'at', 'near', 'by', 'for', 'with', 'and', 'or', 'of', 'my', 'is', 'was', 'lost', 'found'
  ]);

  /**
   * Tokenizes and expands text with synonyms
   */
  static tokenizeAndExpand(text) {
    if (!text) return [];
    const cleanText = text.toLowerCase().replace(/[^a-z0-9\s]/g, ' ');
    const tokens = cleanText.split(/\s+/).filter(t => t.length > 1 && !this.STOP_WORDS.has(t));
    
    const expanded = new Set(tokens);
    tokens.forEach(token => {
      if (this.SYNONYM_MAP[token]) {
        this.SYNONYM_MAP[token].forEach(syn => expanded.add(syn));
      }
      // Check reverse mapping
      Object.keys(this.SYNONYM_MAP).forEach(key => {
        if (this.SYNONYM_MAP[key].includes(token)) {
          expanded.add(key);
        }
      });
    });

    return Array.from(expanded);
  }

  /**
   * Computes Cosine Similarity between two token sets
   */
  static computeCosineSimilarity(textA, textB) {
    const tokensA = this.tokenizeAndExpand(textA);
    const tokensB = this.tokenizeAndExpand(textB);

    if (tokensA.length === 0 || tokensB.length === 0) return 0;

    const vocab = Array.from(new Set([...tokensA, ...tokensB]));
    const vecA = vocab.map(w => tokensA.filter(t => t === w).length);
    const vecB = vocab.map(w => tokensB.filter(t => t === w).length);

    let dotProduct = 0;
    let normA = 0;
    let normB = 0;

    for (let i = 0; i < vocab.length; i++) {
      dotProduct += vecA[i] * vecB[i];
      normA += vecA[i] * vecA[i];
      normB += vecB[i] * vecB[i];
    }

    if (normA === 0 || normB === 0) return 0;
    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
  }

  /**
   * Calculates date proximity score (1.0 for same date, decaying exponentially over days)
   */
  static computeDateProximityScore(dateStrA, dateStrB) {
    try {
      const d1 = new Date(dateStrA).getTime();
      const d2 = new Date(dateStrB).getTime();
      const diffDays = Math.abs(d1 - d2) / (1000 * 3600 * 24);
      if (isNaN(diffDays)) return 0.5;
      return Math.exp(-diffDays / 7); // 7-day half life decay
    } catch (e) {
      return 0.5;
    }
  }

  /**
   * Evaluates match candidate between a Lost item and a Found item
   */
  static matchPair(lostItem, foundItem) {
    const factors = [];

    // 1. Category Score
    const categoryMatch = lostItem.category === foundItem.category;
    const categoryScore = categoryMatch ? 1.0 : 0.0;
    if (categoryMatch) factors.push(`Same Category (${lostItem.category})`);

    // 2. Text Cosine Similarity (Title + Description)
    const textLost = `${lostItem.title} ${lostItem.description}`;
    const textFound = `${foundItem.title} ${foundItem.description}`;
    const textSim = this.computeCosineSimilarity(textLost, textFound);
    if (textSim > 0.3) {
      factors.push(`Keyword Similarity (${Math.round(textSim * 100)}%)`);
    }

    // 3. Location Proximity Score
    const locationMatch = lostItem.location === foundItem.location;
    const locationScore = locationMatch ? 1.0 : 0.3;
    if (locationMatch) factors.push(`Matched Zone (${lostItem.location})`);

    // 4. Date Proximity Score
    const dateScore = this.computeDateProximityScore(lostItem.date, foundItem.date);
    if (dateScore > 0.7) factors.push(`Date Proximity`);

    // Weighted Overall Confidence Score
    const weightedScore = (
      (textSim * 0.45) +
      (categoryScore * 0.25) +
      (locationScore * 0.15) +
      (dateScore * 0.15)
    ) * 100;

    const confidenceScore = Math.min(99, Math.max(0, Math.round(weightedScore)));

    return {
      id: `match_${lostItem.id}_${foundItem.id}`,
      lostItem,
      foundItem,
      confidenceScore,
      textSimilarityScore: Math.round(textSim * 100),
      locationScore: Math.round(locationScore * 100),
      dateScore: Math.round(dateScore * 100),
      matchingFactors: factors,
      isPotentialDuplicate: confidenceScore > 85
    };
  }

  /**
   * Scans existing active items to detect duplicate reports
   */
  static detectDuplicates(newItem, existingItems) {
    return existingItems.filter(item => {
      if (item.id === newItem.id || item.type !== newItem.type) return false;
      const match = this.matchPair(newItem, item);
      return match.confidenceScore >= 80;
    });
  }

  /**
   * Generates ranked matches for a lost item against all found items
   */
  static findMatchesForItem(targetItem, allItems) {
    const candidates = allItems.filter(item => 
      item.id !== targetItem.id && 
      item.type !== targetItem.type &&
      item.status !== 'Resolved'
    );

    return candidates
      .map(candidate => this.matchPair(
        targetItem.type === 'Lost' ? targetItem : candidate,
        targetItem.type === 'Found' ? targetItem : candidate
      ))
      .filter(res => res.confidenceScore >= 35)
      .sort((a, b) => b.confidenceScore - a.confidenceScore);
  }
}
