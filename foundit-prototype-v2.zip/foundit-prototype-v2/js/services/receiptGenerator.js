/**
 * FoundIt v2 Campus Security Custody Handover Receipt Generator
 * Produces verifiable handover receipts for found items deposited at security desks
 */

export class ReceiptGeneratorService {
  static createReceipt(item, finderName, securityOfficerName, badgeNumber) {
    const date = new Date();
    const timestampStr = date.toISOString();
    const receiptNum = `SEC-${date.getFullYear()}${(date.getMonth()+1).toString().padStart(2,'0')}${date.getDate().toString().padStart(2,'0')}-${Math.floor(1000 + Math.random() * 9000)}`;

    return {
      receiptId: receiptNum,
      itemId: item.id,
      itemTitle: item.title,
      category: item.category,
      finderName: finderName || 'Anonymous Student/Staff',
      securityOfficerName: securityOfficerName || 'Officer J. Miller',
      badgeNumber: badgeNumber || 'SEC-8842',
      deskLocation: item.location || 'Library Security Desk',
      timestamp: timestampStr,
      custodyStatus: 'In Vault',
      signatureHash: `SIG-${Math.random().toString(36).substring(2, 10).toUpperCase()}`
    };
  }

  static renderReceiptHTML(receipt) {
    return `
      <div class="receipt-card" style="background:#f8fafc; border:2px dashed #0284c7; border-radius:12px; padding:20px; font-family:system-ui, sans-serif; color:#0f172a; max-width:500px; margin:0 auto;">
        <div style="display:flex; justify-between; align-items:center; border-bottom:1px solid #cbd5e1; padding-bottom:12px; margin-bottom:16px;">
          <div>
            <h3 style="margin:0; color:#0284c7; font-size:18px;">CAMPUS SECURITY HANDOVER RECEIPT</h3>
            <span style="font-size:12px; color:#64748b;">Official Custody Transfer Document</span>
          </div>
          <span style="background:#e0f2fe; color:#0369a1; padding:4px 8px; border-radius:6px; font-family:monospace; font-weight:bold; font-size:12px;">${receipt.receiptId}</span>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; font-size:13px; margin-bottom:16px;">
          <div><strong>Item Deposited:</strong><br><span style="color:#334155;">${receipt.itemTitle}</span></div>
          <div><strong>Category:</strong><br><span style="color:#334155;">${receipt.category}</span></div>
          <div><strong>Security Vault Location:</strong><br><span style="color:#334155;">${receipt.deskLocation}</span></div>
          <div><strong>Custody Status:</strong><br><span style="color:#16a34a; font-weight:600;">🔒 ${receipt.custodyStatus}</span></div>
          <div><strong>Deposited By:</strong><br><span style="color:#334155;">${receipt.finderName}</span></div>
          <div><strong>Receiving Officer:</strong><br><span style="color:#334155;">${receipt.securityOfficerName} (${receipt.badgeNumber})</span></div>
        </div>

        <div style="background:#e2e8f0; padding:10px; border-radius:8px; font-size:11px; font-family:monospace; color:#475569; display:flex; justify-between; align-items:center;">
          <span>TIMESTAMP: ${new Date(receipt.timestamp).toLocaleString()}</span>
          <span>${receipt.signatureHash}</span>
        </div>

        <div style="margin-top:16px; text-align:center;">
          <button onclick="window.print()" style="background:#0284c7; color:#fff; border:none; padding:8px 16px; border-radius:6px; cursor:pointer; font-weight:600;">🖨️ Print Custody Receipt</button>
        </div>
      </div>
    `;
  }
}
