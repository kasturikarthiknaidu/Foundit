/**
 * FoundIt v2 Mock Persistence & API Service Layer
 * LocalStorage management with robust error handling, seed datasets, and security integration
 */

import { SecurityService } from './services/security.js';
import { MatchingEngine } from './services/matchingEngine.js';

const STORAGE_KEY_ITEMS = 'foundit_v2_items';
const STORAGE_KEY_CLAIMS = 'foundit_v2_claims';
const STORAGE_KEY_TAGS = 'foundit_v2_tags';

const SVG_PLACEHOLDER = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="300" height="200" viewBox="0 0 300 200"><rect width="100%" height="100%" fill="%23f1f5f9"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-family="sans-serif" font-size="14" fill="%2364748b">Item Photo Preview</text></svg>';

// Pre-populated campus lost-and-found dataset with 20 items across zones
const SEED_ITEMS = [
  {
    id: 'item_101', type: 'Lost', title: 'Black Sony Over-Ear Headphones', category: 'Electronics',
    location: 'Library', date: '2026-11-19', description: 'Sony WH-1000XM4 noise cancelling headphones in black case.',
    photoUrl: SVG_PLACEHOLDER, status: 'Open', createdAt: '2026-11-19T10:00:00Z',
    proofHint: 'Color of the aux adapter or sticker on the case'
  },
  {
    id: 'item_102', type: 'Found', title: 'Sony Wireless Headphones', category: 'Electronics',
    location: 'Library', date: '2026-11-19', description: 'Found black over-ear Sony headset on Library 2nd floor study desk with audio cable.',
    photoUrl: SVG_PLACEHOLDER, status: 'Open', createdAt: '2026-11-19T14:30:00Z',
    proofHint: 'What color is the attached adapter?'
  },
  {
    id: 'item_103', type: 'Lost', title: 'MacBook Air M2 (Silver)', category: 'Electronics',
    location: 'Computer Lab 2', date: '2026-11-18', description: 'Silver Apple notebook with GitHub and Python stickers on top lid.',
    photoUrl: SVG_PLACEHOLDER, status: 'Open', createdAt: '2026-11-18T16:20:00Z',
    proofHint: 'Specific tech sticker names on bottom right'
  },
  {
    id: 'item_104', type: 'Found', title: 'HP Laptop 15 inch Black', category: 'Electronics',
    location: 'Computer Lab 2', date: '2026-11-18', description: 'Black HP Pavilion notebook computer found near workstation 14.',
    photoUrl: SVG_PLACEHOLDER, status: 'Open', createdAt: '2026-11-18T18:00:00Z'
  },
  {
    id: 'item_105', type: 'Lost', title: 'Blue Hydro Flask 32oz', category: 'Water Bottles',
    location: 'Gym', date: '2026-11-19', description: 'Dark blue hydroflask water bottle with flexible straw lid.',
    photoUrl: SVG_PLACEHOLDER, status: 'Open', createdAt: '2026-11-19T08:15:00Z'
  },
  {
    id: 'item_106', type: 'Found', title: 'Blue Water Bottle (Hydro Flask)', category: 'Water Bottles',
    location: 'Gym', date: '2026-11-19', description: 'Blue metal water bottle turned in near basketball court bench.',
    photoUrl: SVG_PLACEHOLDER, status: 'Open', createdAt: '2026-11-19T11:45:00Z'
  },
  {
    id: 'item_107', type: 'Lost', title: 'Student ID Card - Alex Rivera', category: 'ID Cards & Documents',
    location: 'Cafeteria', date: '2026-11-20', description: 'Campus ID card for CS student Alex Rivera.',
    photoUrl: SVG_PLACEHOLDER, status: 'Open', createdAt: '2026-11-20T12:10:00Z'
  },
  {
    id: 'item_108', type: 'Found', title: 'Found Student ID Badge', category: 'ID Cards & Documents',
    location: 'Cafeteria', date: '2026-11-20', description: 'Official campus ID card found near cafeteria checkout counter.',
    photoUrl: SVG_PLACEHOLDER, status: 'Open', createdAt: '2026-11-20T12:40:00Z'
  },
  {
    id: 'item_109', type: 'Lost', title: 'Toyota Car Key Fob & House Keys', category: 'Keys',
    location: 'Main Gate', date: '2026-11-17', description: 'Black Toyota smart key fob attached to a silver keychain with 3 keys.',
    photoUrl: SVG_PLACEHOLDER, status: 'Open', createdAt: '2026-11-17T17:00:00Z'
  },
  {
    id: 'item_110', type: 'Found', title: 'Key Ring with Car Fob', category: 'Keys',
    location: 'Main Gate', date: '2026-11-17', description: 'Car remote fob and key set discovered near gate 2 security booth.',
    photoUrl: SVG_PLACEHOLDER, status: 'Open', createdAt: '2026-11-17T19:30:00Z'
  },
  {
    id: 'item_111', type: 'Lost', title: 'North Face Black Backpack', category: 'Bags & Backpacks',
    location: 'Main Building', date: '2026-11-16', description: 'Black padded laptop backpack containing notebook and textbook.',
    photoUrl: SVG_PLACEHOLDER, status: 'Resolved', createdAt: '2026-11-16T09:00:00Z'
  },
  {
    id: 'item_112', type: 'Found', title: 'Calculus 2 Textbook', category: 'ID Cards & Documents',
    location: 'Main Building', date: '2026-11-16', description: 'Hardcover mathematics textbook found in lecture hall 101.',
    photoUrl: SVG_PLACEHOLDER, status: 'Open', createdAt: '2026-11-16T11:20:00Z'
  },
  {
    id: 'item_113', type: 'Lost', title: 'Ray-Ban Prescription Glasses', category: 'Clothing & Accessories',
    location: 'Library', date: '2026-11-15', description: 'Black tortoise-shell glasses frame in brown leather case.',
    photoUrl: SVG_PLACEHOLDER, status: 'Open', createdAt: '2026-11-15T15:00:00Z'
  },
  {
    id: 'item_114', type: 'Found', title: 'Glasses Case (Brown)', category: 'Clothing & Accessories',
    location: 'Library', date: '2026-11-15', description: 'Brown protective spectacle case with reading glasses inside.',
    photoUrl: SVG_PLACEHOLDER, status: 'Open', createdAt: '2026-11-15T16:30:00Z'
  },
  {
    id: 'item_115', type: 'Lost', title: 'Anker Power Bank 20000mAh', category: 'Electronics',
    location: 'Cafeteria', date: '2026-11-19', description: 'Heavy matte black portable battery charger with USB-C cable.',
    photoUrl: SVG_PLACEHOLDER, status: 'Open', createdAt: '2026-11-19T13:00:00Z'
  },
  {
    id: 'item_116', type: 'Found', title: 'Black Portable Battery Charger', category: 'Electronics',
    location: 'Cafeteria', date: '2026-11-19', description: 'Power bank unit found under food court table 8.',
    photoUrl: SVG_PLACEHOLDER, status: 'Open', createdAt: '2026-11-19T15:15:00Z'
  },
  {
    id: 'item_117', type: 'Lost', title: 'Denim Jacket (Size M)', category: 'Clothing & Accessories',
    location: 'Sports Complex', date: '2026-11-14', description: 'Blue jean jacket left near tennis court bleachers.',
    photoUrl: SVG_PLACEHOLDER, status: 'Open', createdAt: '2026-11-14T17:45:00Z'
  },
  {
    id: 'item_118', type: 'Found', title: 'Blue Denim Jacket', category: 'Clothing & Accessories',
    location: 'Sports Complex', date: '2026-11-14', description: 'Jean jacket turned in by sports complex staff.',
    photoUrl: SVG_PLACEHOLDER, status: 'Open', createdAt: '2026-11-14T19:00:00Z'
  },
  {
    id: 'item_119', type: 'Lost', title: 'Logitech Wireless Mouse', category: 'Electronics',
    location: 'Computer Lab 2', date: '2026-11-20', description: 'Ergonomic gray USB bluetooth mouse.',
    photoUrl: SVG_PLACEHOLDER, status: 'Open', createdAt: '2026-11-20T10:30:00Z'
  },
  {
    id: 'item_120', type: 'Found', title: 'Computer Mouse (Logitech)', category: 'Electronics',
    location: 'Computer Lab 2', date: '2026-11-20', description: 'Wireless mouse left connected to PC station 4.',
    photoUrl: SVG_PLACEHOLDER, status: 'Open', createdAt: '2026-11-20T11:15:00Z'
  }
];

export class FoundItAPI {
  static initStorage() {
    try {
      if (!localStorage.getItem(STORAGE_KEY_ITEMS)) {
        localStorage.setItem(STORAGE_KEY_ITEMS, JSON.stringify(SEED_ITEMS));
      }
      if (!localStorage.getItem(STORAGE_KEY_CLAIMS)) {
        localStorage.setItem(STORAGE_KEY_CLAIMS, JSON.stringify([]));
      }
      if (!localStorage.getItem(STORAGE_KEY_TAGS)) {
        localStorage.setItem(STORAGE_KEY_TAGS, JSON.stringify([]));
      }
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }

  static async getItems() {
    this.initStorage();
    try {
      const data = localStorage.getItem(STORAGE_KEY_ITEMS);
      return data ? JSON.parse(data) : SEED_ITEMS;
    } catch (e) {
      return SEED_ITEMS;
    }
  }

  static async saveItem(itemData) {
    this.initStorage();
    const items = await this.getItems();
    
    const sanitizedTitle = SecurityService.sanitizeInput(itemData.title);
    const sanitizedDesc = SecurityService.sanitizeInput(itemData.description);

    const newItem = {
      id: `item_${Date.now()}_${Math.floor(Math.random()*1000)}`,
      type: itemData.type,
      title: sanitizedTitle,
      category: itemData.category,
      location: itemData.location,
      date: itemData.date,
      description: sanitizedDesc,
      photoUrl: itemData.photoUrl || SVG_PLACEHOLDER,
      status: 'Open',
      createdAt: new Date().toISOString(),
      proofHint: itemData.proofHint ? SecurityService.sanitizeInput(itemData.proofHint) : undefined
    };

    const duplicates = MatchingEngine.detectDuplicates(newItem, items);
    if (duplicates.length > 0) {
      newItem.isDuplicate = true;
      newItem.duplicateOfId = duplicates[0].id;
    }

    items.unshift(newItem);
    try {
      localStorage.setItem(STORAGE_KEY_ITEMS, JSON.stringify(items));
    } catch (e) {}

    return { item: newItem, duplicates };
  }

  static async submitClaim(claimData) {
    this.initStorage();
    
    const hashedProof = await SecurityService.hashText(claimData.privateProof);
    const newClaim = {
      id: `claim_${Date.now()}`,
      itemId: claimData.itemId,
      claimantName: SecurityService.sanitizeInput(claimData.claimantName),
      claimantEmail: SecurityService.sanitizeInput(claimData.claimantEmail),
      hashedProof,
      submittedAt: new Date().toISOString(),
      status: 'Pending Review',
      verificationAttempts: 0
    };

    const items = await this.getItems();
    const targetItem = items.find(i => i.id === claimData.itemId);
    if (targetItem) {
      targetItem.status = 'Claim Pending';
      try {
        localStorage.setItem(STORAGE_KEY_ITEMS, JSON.stringify(items));
      } catch (e) {}
    }

    let claims = [];
    try {
      claims = JSON.parse(localStorage.getItem(STORAGE_KEY_CLAIMS) || '[]');
    } catch (e) {}
    claims.push(newClaim);
    try {
      localStorage.setItem(STORAGE_KEY_CLAIMS, JSON.stringify(claims));
    } catch (e) {}

    return newClaim;
  }

  static async getMatches(itemId) {
    const items = await this.getItems();
    const target = items.find(i => i.id === itemId);
    if (!target) return [];
    return MatchingEngine.findMatchesForItem(target, items);
  }
}
